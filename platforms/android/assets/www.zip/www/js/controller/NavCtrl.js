app.controller("NavCtrl", function($scope) {
    $scope.menu='home';
});
